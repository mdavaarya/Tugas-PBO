import java.util.Scanner;
import java.util.ArrayList;
public class Admin {
    ArrayList<Student> daftarStu = new ArrayList<>();
    Scanner scan = new Scanner(System.in);
    String loggedNIM; // Menyimpan NIM mahasiswa yang berhasil login
    boolean control = false;

    boolean loginAdmin() {
        System.out.print("Enter your username (admin): ");
        String userAdmin = scan.next();
        System.out.print("Enter your password (admin): ");
        String PassAdmin = scan.next();
        if (!control)
            if (userAdmin.equals("admin") && PassAdmin.equals("admin")) {
                System.out.println("Successful Login as Admin");
                return false;
            } else{
            System.out.println("Admin User Not Found!!");
        }
        return true;

    }

    String setPasStudent() {
        System.out.print("Enter your NIM (masukkan 99 untuk kembali): ");
        String Nim = scan.next();
        if (!control) {
            if (Nim.length() == 15) {
                System.out.println("Successful Login as Student");
                loggedNIM = Nim; // Simpan NIM mahasiswa yang berhasil login
            } else if (Nim.length() <= 15) {
                System.out.println("Maaf anda tidak bisa login");
            }
        }
        return Nim;
    }

    void setAddStudent(){
        Student Stu = new Student();
        System.out.print("Masukkan nama mahasiswa: ");
        Stu.nama = scan.nextLine();
        System.out.print("Masukkan NIM mahasiswa: ");
        Stu.nim = scan.nextLine();
        if (Stu.nim.length() != 15) {
            System.out.println("Panjang NIM harus 15 angka.");
            return;
        }
        System.out.print("Masukkan Faculty: ");
        Stu.faculty = scan.nextLine();
        System.out.print("Masukkan Program: ");
        Stu.programStudy = scan.nextLine();
        System.out.println("Data mahasiswa berhasil ditambahkan.");
        daftarStu.add(Stu);
    }
    void setDisplayStudent(){
        System.out.println("\nData Mahasiswa:");
        for (Student mhs : daftarStu) {
            System.out.println("Nama: " + mhs.getNama());
            System.out.println("Fakultas: " + mhs.getFaculty());
            System.out.println("Program Studi: " + mhs.getProgramStudy());
            System.out.println("NIM: " + mhs.getNim());
            System.out.println("\n");
        }
    }
}





